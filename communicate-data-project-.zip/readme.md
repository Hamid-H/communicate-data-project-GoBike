# Ford GoBike System Data
## by Hamid Alhijaily


## Dataset

> This dataset gathered from people who used Ford GoBike in San Francisco 2017.it contains 453159 rides with 15 feature there are nine numeric columns and two categorical columns.


## Summary of Findings

> San Francisco is a tourist city which means most of the customers are tourists, so they pick the normal ride for 30 minute and the subscriber are people who work in San Francisco and it's efficient for them to pick subscribe version..


## Key Insights for Presentation

> In the presentation, I showed how duration affect from other factors such as summer season the duration of the customer user increased while its decrease in other seasons